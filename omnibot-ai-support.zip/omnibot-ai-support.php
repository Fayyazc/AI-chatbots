<?php
/**
 * Plugin Name: OmniBot AI Customer Support
 * Plugin URI: http://localhost:3000
 * Description: Connect your WordPress website to your Multi-Tenant Gemini AI Customer Support Chatbot. Displays an interactive AI floating chat widget on all pages.
 * Version: 1.0.0
 * Author: OmniBot AI SaaS
 * Author URI: http://localhost:3000
 * License: GPLv2 or later
 * Text Domain: omnibot-ai-support
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class OmniBot_AI_Support_Plugin {
    public function __construct() {
        // Enqueue widget script in site footer
        add_action('wp_footer', array($this, 'inject_widget_script'));
        
        // Register Admin Menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Inject widget.js script into the WordPress website footer
     */
    public function inject_widget_script() {
        $enabled = get_option('omnibot_enabled', '1');
        if ($enabled !== '1') return;

        $server_url = esc_url(get_option('omnibot_server_url', 'http://localhost:5000'));
        $bot_id = esc_attr(get_option('omnibot_bot_id', 'bot_nexus_support'));

        if (empty($server_url) || empty($bot_id)) return;

        // Clean trailing slash
        $server_url = rtrim($server_url, '/');
        
        echo "\n<!-- OmniBot AI Customer Support Widget -->\n";
        echo '<script src="' . $server_url . '/widget.js" data-bot-id="' . $bot_id . '" async defer></script>' . "\n";
    }

    /**
     * Add Settings Page under WP Admin Options
     */
    public function add_admin_menu() {
        add_options_page(
            'OmniBot AI Support Settings',
            'OmniBot AI Support',
            'manage_options',
            'omnibot-ai-support',
            array($this, 'render_admin_page')
        );
    }

    /**
     * Register Plugin Options in WP DB
     */
    public function register_settings() {
        register_setting('omnibot_options_group', 'omnibot_server_url');
        register_setting('omnibot_options_group', 'omnibot_bot_id');
        register_setting('omnibot_options_group', 'omnibot_enabled');
    }

    /**
     * Render WP Admin Settings UI
     */
    public function render_admin_page() {
        $server_url = get_option('omnibot_server_url', 'http://localhost:5000');
        $bot_id = get_option('omnibot_bot_id', 'bot_nexus_support');
        $enabled = get_option('omnibot_enabled', '1');
        ?>
        <div class="wrap">
            <h1 style="display:flex; align-items:center; gap:10px;">
                <span style="background:#6366f1; color:white; border-radius:8px; padding:4px 10px; font-size:18px;">🤖</span>
                OmniBot AI Customer Support Configuration
            </h1>
            <p>Connect your WordPress website to your AI Support SaaS Chatbot powered by Gemini AI.</p>

            <form method="post" action="options.php" style="background:#fff; padding:24px; border-radius:12px; border:1px solid #ccd0d4; max-width:650px; margin-top:20px; box-shadow:0 4px 12px rgba(0,0,0,0.05);">
                <?php settings_fields('omnibot_options_group'); ?>
                
                <table class="form-table" style="width:100%;">
                    <tr valign="top">
                        <th scope="row" style="width:180px;"><label for="omnibot_enabled">Enable AI Chatbot</label></th>
                        <td>
                            <input type="checkbox" id="omnibot_enabled" name="omnibot_enabled" value="1" <?php checked('1', $enabled); ?> />
                            <label for="omnibot_enabled">Publish floating AI Chat Widget on all website pages</label>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><label for="omnibot_server_url">SaaS Server URL</label></th>
                        <td>
                            <input type="url" id="omnibot_server_url" name="omnibot_server_url" value="<?php echo esc_attr($server_url); ?>" class="regular-text" required placeholder="http://localhost:5000" />
                            <p class="description">The backend server URL running your AI SaaS (e.g. http://localhost:5000 or https://your-saas-domain.com)</p>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><label for="omnibot_bot_id">Bot ID</label></th>
                        <td>
                            <input type="text" id="omnibot_bot_id" name="omnibot_bot_id" value="<?php echo esc_attr($bot_id); ?>" class="regular-text" required placeholder="bot_nexus_support" />
                            <p class="description">Copy your unique Bot ID from your SaaS Dashboard (e.g., bot_nexus_support)</p>
                        </td>
                    </tr>
                </table>

                <?php submit_button('Save Changes & Publish Widget'); ?>
            </form>

            <div style="background:#f0fdf4; border:1px solid #bbf7d0; color:#166534; padding:16px; border-radius:8px; max-width:650px; margin-top:20px;">
                <strong>⚡ Status Verification:</strong> 
                <?php if ($enabled === '1' && !empty($bot_id)): ?>
                    Widget is active! The AI chatbot floating launcher button is published at the bottom right of your site.
                <?php else: ?>
                    Widget is currently disabled or missing Bot ID.
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}

new OmniBot_AI_Support_Plugin();
