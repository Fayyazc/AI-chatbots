=== OmniBot AI Customer Support ===
Contributors: omnibot-ai
Tags: ai, chatbot, customer support, gemini, intercom, tidio, widget
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later

Connect your WordPress website to your Multi-Tenant Gemini AI Customer Support Chatbot.

== Description ==

OmniBot AI Customer Support seamlessly embeds an interactive floating AI chatbot button on your WordPress website. Powered by Google Gemini AI and your custom Knowledge Base, it answers visitor questions 24/7.

== Features ==
* 1-Click activation of AI floating chat launcher button on all pages.
* Automatically syncs with your SaaS Knowledge Base (FAQs, scraped URLs, document text).
* Zero impact on page speed with asynchronous widget loading.
* Easy configuration page under WP Admin -> Settings -> OmniBot AI Support.

== Installation ==

1. Upload the `wordpress-plugin` folder to your `/wp-content/plugins/` directory (or compress it into `omnibot-ai-support.zip` and upload via WP Admin -> Plugins -> Add New -> Upload Plugin).
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to **Settings -> OmniBot AI Support** in your WP Admin sidebar.
4. Enter your **SaaS Server URL** (e.g. `http://localhost:5000`) and **Bot ID** (e.g. `bot_nexus_support`).
5. Save changes. The interactive AI chatbot launcher button is now published on your website!
